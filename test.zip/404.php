<?php


echo'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
	<title>Ошибка 404</title>
	</head>
	<body>
		<table width="700" cellpadding="4" cellspacing="1" border="0" align="center">
		  <tr>
			<td>
			  <h1>Ошибка 404</h1>
			</td>
		  </tr>
		  <tr>
			<td>
			  <h2>
На странице произошла ошибка 404
</h2>
			</td>
		  </tr>
		  <tr>
			<td>
			  <span class="leftMenu"><a href="javascript:history.back(-1)">Вернуться</a></span>
			</td>
		  </tr>
		</table>
	</body>
</html>';		


 